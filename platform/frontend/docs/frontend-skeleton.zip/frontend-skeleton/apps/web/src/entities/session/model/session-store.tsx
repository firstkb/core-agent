import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type PropsWithChildren
} from "react";
import type { Session } from "./types";

type SessionContextValue = {
  session: Session | null;
  isBootstrapping: boolean;
  setSession: (session: Session) => void;
  clearSession: () => void;
};

const STORAGE_KEY = "acme.session";
const SessionContext = createContext<SessionContextValue | null>(null);

export function SessionProvider({ children }: PropsWithChildren) {
  const [session, setSessionState] = useState<Session | null>(null);
  const [isBootstrapping, setIsBootstrapping] = useState(true);

  useEffect(() => {
    const raw = window.localStorage.getItem(STORAGE_KEY);

    if (raw) {
      try {
        const parsed = JSON.parse(raw) as Session;
        setSessionState(parsed);
      } catch {
        window.localStorage.removeItem(STORAGE_KEY);
      }
    }

    setIsBootstrapping(false);
  }, []);

  const setSession = (nextSession: Session) => {
    setSessionState(nextSession);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(nextSession));
  };

  const clearSession = () => {
    setSessionState(null);
    window.localStorage.removeItem(STORAGE_KEY);
  };

  const value = useMemo<SessionContextValue>(
    () => ({
      session,
      isBootstrapping,
      setSession,
      clearSession
    }),
    [session, isBootstrapping]
  );

  return (
    <SessionContext.Provider value={value}>{children}</SessionContext.Provider>
  );
}

export function useSession() {
  const context = useContext(SessionContext);

  if (!context) {
    throw new Error("useSession must be used inside SessionProvider");
  }

  return context;
}
