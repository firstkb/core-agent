# @acme/api-client

This package is the only place that should know raw endpoint paths.

## Rules

- `src/generated/**` is generated from OpenAPI and should not be edited by hand.
- Features and entities consume typed helpers exported from this package.
- Replace the sample schema with the real schema emitted by the Go backend.

## Suggested generation pipeline

```bash
openapi-typescript ./openapi/schema.yaml -o ./src/generated/schema.ts
```
