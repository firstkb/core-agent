import { z } from "zod";

const schema = z.object({
  VITE_APP_NAME: z.string().default("Acme Console"),
  VITE_API_BASE_URL: z.string().url().default("http://localhost:8080")
});

export const env = schema.parse({
  VITE_APP_NAME: import.meta.env.VITE_APP_NAME,
  VITE_API_BASE_URL: import.meta.env.VITE_API_BASE_URL
});
