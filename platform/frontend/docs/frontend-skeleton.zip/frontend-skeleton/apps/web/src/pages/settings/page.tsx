import { Card } from "@acme/ui";
import { PageSection } from "@/shared/ui/page-section";

export function SettingsPage() {
  return (
    <PageSection
      title="Settings"
      description="Place user-facing configuration screens here and delegate behavior to features."
    >
      <Card>
        <strong>Recommended settings split</strong>
        <ul className="helper-list">
          <li>profile</li>
          <li>security</li>
          <li>notifications</li>
          <li>appearance</li>
          <li>organization</li>
        </ul>
      </Card>
    </PageSection>
  );
}
