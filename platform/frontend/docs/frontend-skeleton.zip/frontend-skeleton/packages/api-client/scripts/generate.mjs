console.log(`
Replace this script with your real schema generation pipeline, for example:

  openapi-typescript ./openapi/schema.yaml -o ./src/generated/schema.ts

Do not hand-edit files inside src/generated/.
`);
