import type { PropsWithChildren, ReactNode } from "react";

type Props = PropsWithChildren<{
  title: string;
  description?: string;
  actions?: ReactNode;
}>;

export function PageSection({
  title,
  description,
  actions,
  children
}: Props) {
  return (
    <section className="page-section">
      <header className="page-section__header">
        <div>
          <h1 className="page-section__title">{title}</h1>
          {description ? (
            <p className="page-section__description">{description}</p>
          ) : null}
        </div>

        {actions}
      </header>

      {children}
    </section>
  );
}
