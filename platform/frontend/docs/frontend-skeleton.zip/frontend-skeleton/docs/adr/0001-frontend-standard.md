# ADR 0001: Frontend standard

## Status

Accepted

## Context

Backend is a Go modular monolith.
Frontend needs to scale to a large application while staying easy to evolve with AI agents.

## Decision

We use:

- React
- TypeScript with `strict`
- Vite
- React Router
- TanStack Query
- pnpm workspaces
- OpenAPI-based client generation
- Feature-first layered architecture

## Consequences

### Positive

- Strong typing and predictable code generation
- Low ambiguity for AI tools
- Clear place for each responsibility
- Easy to split UI primitives into a package
- Easy to keep contract with Go backend explicit

### Negative

- Requires discipline around boundaries
- Monorepo adds some workspace overhead
- Initial setup is stricter than a template-first approach
