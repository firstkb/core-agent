import { Outlet } from "react-router-dom";
import { CurrentUserBadge } from "@/entities/session";
import { SignOutButton } from "@/features/session/sign-out";
import { SidebarNav } from "@/widgets/sidebar-nav";

export function AppShell() {
  return (
    <div className="app-shell">
      <aside className="app-shell__sidebar">
        <div className="app-shell__brand">Acme Console</div>
        <SidebarNav />
      </aside>

      <div className="app-shell__content">
        <header className="app-shell__header">
          <div>
            <strong>Frontend modular monolith</strong>
          </div>

          <div className="user-row">
            <CurrentUserBadge />
            <SignOutButton />
          </div>
        </header>

        <main className="app-shell__main">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
