export interface components {
  schemas: {
    SignInRequest: {
      email: string;
      password: string;
    };
    User: {
      id: string;
      email: string;
      name: string;
    };
    Session: {
      accessToken: string;
      refreshToken?: string;
      user: components["schemas"]["User"];
    };
  };
}

type Json<T> = {
  "application/json": T;
};

export interface paths {
  "/v1/auth/login": {
    post: {
      requestBody: {
        content: Json<components["schemas"]["SignInRequest"]>;
      };
      responses: {
        200: {
          content: Json<components["schemas"]["Session"]>;
        };
      };
    };
  };
  "/v1/me": {
    get: {
      responses: {
        200: {
          content: Json<components["schemas"]["Session"]>;
        };
      };
    };
  };
}

export type SignInRequestDto = components["schemas"]["SignInRequest"];
export type SessionDto = components["schemas"]["Session"];
export type UserDto = components["schemas"]["User"];
