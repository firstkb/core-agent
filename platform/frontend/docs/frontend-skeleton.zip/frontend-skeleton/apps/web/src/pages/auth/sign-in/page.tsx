import { SignInForm } from "@/features/auth/sign-in-with-password";

export function SignInPage() {
  return (
    <main className="sign-in-layout">
      <SignInForm />
    </main>
  );
}
