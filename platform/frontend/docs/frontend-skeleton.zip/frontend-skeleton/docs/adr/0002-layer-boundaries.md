# ADR 0002: Layer boundaries

## Status

Accepted

## Decision

We enforce directional dependencies:

```txt
app      -> pages, widgets, features, entities, shared
pages    -> widgets, features, entities, shared
widgets  -> features, entities, shared
features -> entities, shared
entities -> shared
shared   -> shared
```

## Rationale

This minimizes coupling and reduces accidental architectural drift.

## Notes

- `pages` stay thin.
- `widgets` are layout-level or page-block-level compositions.
- `features` implement user actions and use-cases.
- `entities` hold domain nouns and local business structure.
- `shared` contains non-domain primitives.
