import { createApiClient } from "@acme/api-client";
import { env } from "@/shared/config/env";

const api = createApiClient(env.VITE_API_BASE_URL);

export async function getMe() {
  const response = await api.GET("/v1/me");

  if (response.error) {
    throw new Error("Failed to load current session");
  }

  return response.data;
}
