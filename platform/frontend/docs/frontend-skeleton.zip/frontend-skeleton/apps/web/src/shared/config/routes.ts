export const routes = {
  dashboard: "/",
  settings: "/settings",
  signIn: "/signin"
} as const;
