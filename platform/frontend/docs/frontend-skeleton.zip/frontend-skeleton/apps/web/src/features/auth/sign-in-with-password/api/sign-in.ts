import type { Session } from "@/entities/session";
import type { SignInInput } from "../model/schema";

/**
 * Replace this stub with a real typed call from @acme/api-client:
 *
 *   const api = createApiClient(env.VITE_API_BASE_URL);
 *   const { data, error } = await api.POST("/v1/auth/login", { body: input });
 */
export async function signInWithPassword(
  input: SignInInput
): Promise<Session> {
  await new Promise((resolve) => window.setTimeout(resolve, 300));

  return {
    accessToken: "dev-access-token",
    refreshToken: "dev-refresh-token",
    user: {
      id: `user-${Date.now()}`,
      email: input.email,
      name: input.email.split("@")[0] ?? "user"
    }
  };
}
