import { useNavigate } from "react-router-dom";
import { Button } from "@acme/ui";
import { useSession } from "@/entities/session";
import { routes } from "@/shared/config/routes";

export function SignOutButton() {
  const navigate = useNavigate();
  const { clearSession } = useSession();

  const handleClick = () => {
    clearSession();
    navigate(routes.signIn);
  };

  return (
    <Button variant="secondary" onClick={handleClick}>
      Sign out
    </Button>
  );
}
