import { Card } from "@acme/ui";
import { PageSection } from "@/shared/ui/page-section";

export function DashboardPage() {
  return (
    <PageSection
      title="Dashboard"
      description="Thin page component. Domain logic should live in features and entities."
    >
      <div className="page-grid">
        <Card>
          <div className="metric">
            <span className="metric__label">Architecture</span>
            <span className="metric__value">FSD-lite</span>
          </div>
        </Card>

        <Card>
          <div className="metric">
            <span className="metric__label">Contracts</span>
            <span className="metric__value">OpenAPI</span>
          </div>
        </Card>

        <Card>
          <div className="metric">
            <span className="metric__label">Server state</span>
            <span className="metric__value">Query</span>
          </div>
        </Card>
      </div>

      <Card>
        <strong>What belongs here</strong>
        <ul className="helper-list">
          <li>composition of widgets and features</li>
          <li>page title and page-level layout concerns</li>
          <li>no direct data fetching with raw URLs</li>
        </ul>
      </Card>
    </PageSection>
  );
}
