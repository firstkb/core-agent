# Frontend skeleton

Monorepo skeleton for a large React frontend that talks to a Go modular monolith.

## Stack

- React + TypeScript strict
- Vite
- React Router
- TanStack Query
- pnpm workspaces + Turborepo
- OpenAPI client package
- Vitest + Playwright
- Feature-first layered structure

## Workspace layout

```txt
apps/
  web/            # main product frontend
packages/
  ui/             # shared design-system primitives
  api-client/     # generated OpenAPI client and schema
docs/
  adr/            # architectural decision records
AGENTS.md         # rules for humans and AI agents
```

## Commands

```bash
pnpm install
pnpm dev
pnpm build
pnpm lint
pnpm typecheck
pnpm test
pnpm e2e
```

## Layer rules inside `apps/web/src`

```txt
app      -> pages, widgets, features, entities, shared
pages    -> widgets, features, entities, shared
widgets  -> features, entities, shared
features -> entities, shared
entities -> shared
shared   -> shared
```

## API contract rule

Only `packages/api-client` knows raw endpoint paths.  
Application code should never scatter URL strings across features and pages.

## How to add a new business capability

1. Create a slice under `src/features/<domain>/<use-case>/`.
2. Add UI, model and api files inside that slice.
3. Compose the feature from a page or widget.
4. If backend contract changes, regenerate `packages/api-client`.
5. Never deep-import internals from another slice.

## Optional next step

If you later decide to adopt shadcn/ui or Radix, add them inside `packages/ui`.
The repository shape stays the same.
