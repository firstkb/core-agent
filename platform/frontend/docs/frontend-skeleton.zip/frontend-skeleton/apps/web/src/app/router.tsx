import { Navigate, Outlet, createBrowserRouter } from "react-router-dom";
import { DashboardPage } from "@/pages/dashboard/page";
import { SettingsPage } from "@/pages/settings/page";
import { SignInPage } from "@/pages/auth/sign-in/page";
import { AppShell } from "@/widgets/app-shell";
import { useSession } from "@/entities/session";
import { routes } from "@/shared/config/routes";

function ProtectedRoute() {
  const { isBootstrapping, session } = useSession();

  if (isBootstrapping) {
    return <div className="app-loading">Loading...</div>;
  }

  if (!session) {
    return <Navigate to={routes.signIn} replace />;
  }

  return <AppShell />;
}

function PublicOnlyRoute() {
  const { isBootstrapping, session } = useSession();

  if (isBootstrapping) {
    return <div className="app-loading">Loading...</div>;
  }

  if (session) {
    return <Navigate to={routes.dashboard} replace />;
  }

  return <Outlet />;
}

export const router = createBrowserRouter([
  {
    element: <PublicOnlyRoute />,
    children: [
      {
        path: routes.signIn,
        element: <SignInPage />
      }
    ]
  },
  {
    element: <ProtectedRoute />,
    children: [
      {
        path: routes.dashboard,
        element: <DashboardPage />
      },
      {
        path: routes.settings,
        element: <SettingsPage />
      }
    ]
  }
]);
