import { useSession } from "../model/session-store";

export function CurrentUserBadge() {
  const { session } = useSession();

  if (!session) {
    return null;
  }

  return (
    <div className="user-badge">
      <span className="user-badge__name">{session.user.name}</span>
      <span className="user-badge__email">{session.user.email}</span>
    </div>
  );
}
