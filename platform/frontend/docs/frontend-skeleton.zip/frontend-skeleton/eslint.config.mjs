import js from "@eslint/js";
import globals from "globals";
import tseslint from "typescript-eslint";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";

const layerBoundary = (files, forbidden) => ({
  files,
  rules: {
    "no-restricted-imports": [
      "error",
      {
        patterns: forbidden
      }
    ]
  }
});

export default tseslint.config(
  {
    ignores: [
      "**/dist/**",
      "**/coverage/**",
      "**/.turbo/**",
      "**/playwright-report/**"
    ]
  },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      globals: {
        ...globals.browser,
        ...globals.node
      }
    },
    plugins: {
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      "react-refresh/only-export-components": [
        "warn",
        { "allowConstantExport": true }
      ]
    }
  },
  layerBoundary(
    ["apps/web/src/entities/**/*.{ts,tsx}"],
    ["@/app/*", "@/pages/*", "@/widgets/*", "@/features/*"]
  ),
  layerBoundary(
    ["apps/web/src/features/**/*.{ts,tsx}"],
    ["@/app/*", "@/pages/*", "@/widgets/*"]
  ),
  layerBoundary(
    ["apps/web/src/widgets/**/*.{ts,tsx}"],
    ["@/app/*", "@/pages/*"]
  ),
  layerBoundary(
    ["apps/web/src/pages/**/*.{ts,tsx}"],
    ["@/app/*"]
  )
);
