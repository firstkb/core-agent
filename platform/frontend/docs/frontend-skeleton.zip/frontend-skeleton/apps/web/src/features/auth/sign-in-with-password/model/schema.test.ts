import { describe, expect, it } from "vitest";
import { signInSchema } from "./schema";

describe("signInSchema", () => {
  it("accepts valid credentials", () => {
    expect(() =>
      signInSchema.parse({
        email: "team@example.com",
        password: "supersecret"
      })
    ).not.toThrow();
  });

  it("rejects invalid email", () => {
    expect(() =>
      signInSchema.parse({
        email: "broken-email",
        password: "supersecret"
      })
    ).toThrow();
  });
});
