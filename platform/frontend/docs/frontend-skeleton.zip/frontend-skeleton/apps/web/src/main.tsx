import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { AppProviders } from "@/app/providers";
import "@/app/styles/globals.css";

const container = document.getElementById("root");

if (!container) {
  throw new Error("Root container was not found");
}

createRoot(container).render(
  <StrictMode>
    <AppProviders />
  </StrictMode>
);
