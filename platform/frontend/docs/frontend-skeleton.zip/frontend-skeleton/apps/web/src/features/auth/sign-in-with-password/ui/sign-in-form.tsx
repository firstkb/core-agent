import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Card, Input } from "@acme/ui";
import { useSession } from "@/entities/session";
import { routes } from "@/shared/config/routes";
import {
  signInSchema,
  type SignInInput
} from "../model/schema";
import { signInWithPassword } from "../api/sign-in";

const initialState: SignInInput = {
  email: "",
  password: ""
};

export function SignInForm() {
  const navigate = useNavigate();
  const { setSession } = useSession();
  const [form, setForm] = useState<SignInInput>(initialState);
  const [error, setError] = useState<string | null>(null);
  const [isPending, setIsPending] = useState(false);

  const updateField = (key: keyof SignInInput, value: string) => {
    setForm((current) => ({
      ...current,
      [key]: value
    }));
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    const result = signInSchema.safeParse(form);

    if (!result.success) {
      setError(result.error.issues[0]?.message ?? "Invalid credentials");
      return;
    }

    try {
      setIsPending(true);
      const session = await signInWithPassword(result.data);
      setSession(session);
      navigate(routes.dashboard);
    } catch (submitError) {
      const message =
        submitError instanceof Error
          ? submitError.message
          : "Authentication failed";

      setError(message);
    } finally {
      setIsPending(false);
    }
  };

  return (
    <Card className="sign-in-card">
      <div>
        <h1 className="sign-in-card__title">Sign in</h1>
        <p className="sign-in-card__description">
          Start with a simple auth flow, then swap the stub for the typed API client.
        </p>
      </div>

      <form className="form-grid" onSubmit={handleSubmit}>
        <div className="form-row">
          <label className="form-label" htmlFor="email">
            Email
          </label>
          <Input
            id="email"
            name="email"
            autoComplete="email"
            placeholder="team@example.com"
            value={form.email}
            onChange={(event) => updateField("email", event.target.value)}
          />
        </div>

        <div className="form-row">
          <label className="form-label" htmlFor="password">
            Password
          </label>
          <Input
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            placeholder="supersecret"
            value={form.password}
            onChange={(event) => updateField("password", event.target.value)}
          />
        </div>

        {error ? <div className="form-error">{error}</div> : null}

        <Button type="submit" disabled={isPending}>
          {isPending ? "Signing in..." : "Sign in"}
        </Button>
      </form>
    </Card>
  );
}
