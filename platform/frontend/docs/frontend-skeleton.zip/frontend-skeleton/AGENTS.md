# AGENTS.md

## Mission

This repository is optimized for predictable AI-assisted development.
Prefer local, explicit, typed code over magical abstractions.

## Architecture rules

1. This is a frontend modular monolith.
2. Do not introduce microfrontends.
3. Do not add a global store for server state. Use TanStack Query.
4. Do not call backend endpoints directly from pages or widgets.
5. Only `packages/api-client` may own raw endpoint paths and schema-derived types.
6. Generated files in `packages/api-client/src/generated/**` are read-only.
7. Keep business logic inside `features` or `entities`, not inside pages.
8. Pages should compose slices, not implement domain logic.
9. Widgets are large UI blocks. Features are business actions. Entities are business nouns.
10. Do not create project-wide `utils/`, `services/`, or `components/` dumping grounds.

## Layer dependencies

```txt
app      -> pages, widgets, features, entities, shared
pages    -> widgets, features, entities, shared
widgets  -> features, entities, shared
features -> entities, shared
entities -> shared
shared   -> shared
```

## Naming

- folders: kebab-case
- React components: PascalCase
- hooks: useX
- route constants: `shared/config/routes.ts`
- environment parsing: `shared/config/env.ts`

## When adding API work

1. Update the OpenAPI schema from backend.
2. Regenerate the API client.
3. Expose typed functions from `packages/api-client`.
4. Consume those typed functions from `features/*/api` or `entities/*/api`.

## Guardrails

- No deep imports across slices.
- No direct localStorage usage outside entities or shared boundary modules.
- No UI side effects inside schema files.
- No feature-specific code inside `packages/ui`.

## Quality gate before commit

Run:

```bash
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```
