import createFetchClient from "openapi-fetch";
import type { paths } from "./generated/schema";

export function createApiClient(baseUrl: string) {
  return createFetchClient<paths>({
    baseUrl
  });
}
