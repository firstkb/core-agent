import { NavLink } from "react-router-dom";
import { routes } from "@/shared/config/routes";

const items = [
  { to: routes.dashboard, label: "Dashboard", end: true },
  { to: routes.settings, label: "Settings" }
];

export function SidebarNav() {
  return (
    <nav className="sidebar-nav" aria-label="Main navigation">
      {items.map((item) => (
        <NavLink
          key={item.to}
          end={item.end}
          to={item.to}
          className={({ isActive }) =>
            isActive
              ? "sidebar-nav__link sidebar-nav__link--active"
              : "sidebar-nav__link"
          }
        >
          {item.label}
        </NavLink>
      ))}
    </nav>
  );
}
